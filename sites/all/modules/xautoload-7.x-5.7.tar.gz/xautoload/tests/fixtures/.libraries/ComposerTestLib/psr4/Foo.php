<?php


namespace ComposerTestLib;


class Foo {

} 
