<?php

namespace Drupal\xautoload_test_4\testlib;

class TestClass {

} 
